package com.example.paymentstripe.model

data class CustomerModel(
    val id:String
)
