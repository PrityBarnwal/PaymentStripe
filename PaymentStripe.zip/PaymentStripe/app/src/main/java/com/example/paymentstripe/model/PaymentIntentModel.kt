package com.example.paymentstripe.model

data class PaymentIntentModel(
    val id:String,
    val client_secret:String
)
