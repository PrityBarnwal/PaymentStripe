package com.example.paymentstripe

object Utils {
     const val PUBLISHABLE_KEY = ""
     const val KEY = ""

}