package com.example.paymentstripe.model


data class EpheralModel(
    val secret: String,
)

